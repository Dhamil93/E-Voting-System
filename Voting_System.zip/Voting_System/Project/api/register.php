<?php

include('connection.php');



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $name = $_POST['name'];

    $faculty = $_POST['faculty'];

    $department = $_POST['department'];

    $email = $_POST['email'];

    $sid = $_POST['sid'];

    $pass = $_POST['pass'];

    $question = $_POST['ques'];

    $answer = $_POST['ans'];

    $date = date('d-m-Y');



    $check = mysqli_query($con, "select * from register where sid='$sid' ");



    if (mysqli_num_rows($check) > 0) {

        echo json_encode($response['success'] = 0);

    } else {

        $enc_pass = md5($pass);

        $enc_pass1 = sha1($enc_pass);

        $enc_pass2 = password_hash($enc_pass1, PASSWORD_DEFAULT);







        // Store the decryption key

        $view_vote_code = "#vote" . time() . rand(100000, 999999);





        $to = $email;

        $subject = "Your code to view the vote";

        $txt = "Hello!\n\nHere is your code to view the vote: $view_vote_code";

        // $headers = "From: damilareatilola@gmail.com" . "\r\n";



        try {

            (mail($to, $subject, $txt));
            

        } catch (Exception $e) {

            echo $e->getMessage();
            

        }



        // $query = mysqli_query($con, "insert into register (name, faculty, department, email, sid, password, sec_q_id, sec_ans, status, created_at) values('$name','$faculty','$department','$email','$sid','$enc_pass2',$question,$answer,0,'$date')");

        $query = mysqli_query($con, "INSERT INTO `register`(`name`, `faculty`, `department`, `email`, `sid`, `password`, `sec_q_id`, `sec_ans`, `status`, `created_at`,`view_vote_code`) 

                                        VALUES ('$name','$faculty','$department','$email','$sid','$enc_pass2','$question','$answer','0','$date','$view_vote_code')");

        if ($query) {

            echo json_encode($response['success'] = 1);

        } else {

            echo json_encode($response['success'] = 0);

        }

    }

}

