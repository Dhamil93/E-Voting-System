<?php
$con = mysqli_connect('localhost','id20857460_vote','Damilare1!','id20857460_vote') or die(mysqli_error($con));
?>
