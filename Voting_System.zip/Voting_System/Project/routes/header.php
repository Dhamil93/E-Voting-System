<!-- This website provides a streamlined online voting system to make the voting process easier and more efficient.
The website has a simple, attractive design with a prominent "Online Voting System" brand. -->
<div id="headerSection" class="sticky-top">
    <div class="container" >
        <div class="row">
            <div class="col-sm-12 text-center pt-3">
                <p id="brand">Online Voting System</p>
            </div>
        </div>
    </div>
</div>