<?php
session_start();
include_once('../api/connection.php');
/* This check is to ensure that only logged in users can access the page. */
/*If the user is not logged in, they will be redirected to the homepage. */
if (!isset($_SESSION['user_id']) &&  !isset($_SESSION['admin_id'])) {
    header('location:../');
}

$isAdmin = false;

if (isset($_SESSION['admin_id'])) {
    $isAdmin = true;
}
?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <title>E-voting - Voting Panel</title>
    <link rel="stylesheet" href="../resources/Bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../resources/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../resources/css/stylesheet.css">
    <script src="../resources/Jquery/jquery-3.5.1.js"></script>
    <script src="../resources/Bootstrap/js/bootstrap.min.js"></script>
    <script src="../resources/js/sweetalert.min.js"></script>
</head>

<body>

    <div id="headerSection" class="sticky-top">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8 text-center pt-3">
                    <p id="brand">E Voting System</p>
                </div>
                <div class="col-md-2 text-center ">
                    <h5><a style="color:white; text-decoration:none" href="<?php echo $isAdmin ? 'dashboard.php' : 'main.php' ?>"><i class="fa fa-s"></i> Go back</a></h5>
                </div>
                <div class="col-md-2 text-center ">
                    <h5><a style="color:white; text-decoration:none" href="<?php echo $isAdmin ? 'ad_logout.php' : 'logout.php' ?>">Logout <i class="fa fa-user-circle"></i></a></h5>
                </div>

            </div>
        </div>
    </div>
    <?php
    // To get the value of maximum vote
    $sql = mysqli_query($con, "SELECT MAX(vote_count) AS max_vote_count
    FROM (
      SELECT COUNT(v.c_id) AS vote_count
      FROM voting as v
      JOIN candidates as c
      ON v.c_id = c.id
      GROUP BY c.id
    ) as vote_counts;
    ");
    $row = mysqli_fetch_array($sql);

    // To get the details of candidate(s) of the maximum value
    $sql2 = mysqli_query($con, "SELECT c.*
    FROM voting as v
    JOIN candidates as c
    ON v.c_id = c.id
    GROUP BY c.id
    HAVING COUNT(v.c_id) = (
      SELECT MAX(vote_count) AS max_vote_count
      FROM (
        SELECT COUNT(v.c_id) AS vote_count
        FROM voting as v
        JOIN candidates as c
        ON v.c_id = c.id
        where c.status=2
        GROUP BY c.id
      ) as vote_counts
    );");

    ?>

    <div>
        <div class="container">

            <?php

            $winner = false;

            if (mysqli_num_rows($sql2) != 0) {
                $winner = true;

            ?>

                <div class="row py-5 form shadow px-5 pb-3 pt-2 d-flex justify-content-center">
                    <div class="col-12 text-center">
                        <h1 class="text-primary">WINNER!!</h1>
                    </div>
                    <?php
                    while ($res = mysqli_fetch_array($sql2)) {
                    ?>
                        <div class="col-3">
                            <div class="text-center">
                                <img src="../uploads/<?= $res['image'] ?>" width="150" height="150" alt="">
                                <h2><?= $res['name'] ?></h2>
                                <h4>Collected: <?= $row['max_vote_count'] ?> Votes </h4>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                </div>

            <?php
            }
            ?>

            <div class="row py-3">

                <?php if (!$isAdmin && $winner) { 
                    // var_dump($winner);
                    ?>
                    
                    <button type="button" id="startBtn" class="btn btn-success" data-toggle="modal" data-target="#startModal">
                        Check Your Vote
                    </button>
                <?php } ?>
                <div class="form shadow w-100 p-5 text-center">
                    <table class="table w-100">
                        <thead>
                            <th>#</th>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Total Votes</th>
                        </thead>
                        <tbody>

                            <?php

                            $sql = mysqli_query($con, "SELECT cnd.name,cnd.image,cnd.category,count(vt.c_id) as vote
                                                    from candidates as cnd
                                                    left join voting as vt
                                                    on cnd.id=vt.c_id
                                                    -- where cnd.status=2
                                                
                                                    group by cnd.id
                                                    order by vote desc

                                            ");

                            $i = 1;
                            while ($row = mysqli_fetch_array($sql)) {
                            ?>
                                <tr class="py-2">
                                    <td><b><?php echo $i++ ?></b></td>
                                    <td><img src="../uploads/<?= $row['image'] ?>" alt="" width="60px" height="60px"></td>
                                    <td><?= $row['name'] ?></td>
                                    <td><?= $row['category'] ?></td>
                                    <td><?= $row['vote'] ?></td>
                                </tr>
                            <?php
                            }
                            ?>

                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>

    <!-- Verify vote Modal -->
    <div class="modal fade" id="startModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Enter your code</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-row text-center">
                            <div class="col-md-10 pb-1">
                                <input id="viewVoteCode" class="form-control py-1" type="password"></input>
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-primary" id="verifyCodeBtn" type="button">Verify</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>




    <!-- view vote Modal -->
    <div class="modal fade" id="viewVoteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">You Voted</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="container">

                        <div class="row align-items-center">
                            <div class="col-lg-6">
                                <img src="../uploads/47097_45202_500_775_jpg.jpg" id="votedCandImg" class="img-fluid" style="height: 215px;">
                            </div>
                            <div class="col-lg-6">
                                <h6>Name: <span id='votedCandName'></span></h6>
                                <br>
                                <h6>Category: <span id='votedCandCategory'></span></h6>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

</html>

<script>
    $("#verifyCodeBtn").click(function() {

        var code = $("#viewVoteCode").val();

        if (code == '') {
            alert('Code cannot be blank!');
        } else {
            $.ajax({
                url: '../api/verify.php',
                type: 'POST',
                dataType: 'json',
                contentType: 'application/json',
                data: JSON.stringify({
                    call: 5,
                    code: code,
                }),
                success: function(data) {
                    console.log(data);
                    if (data['success'] == 1) {

                        let candidate = data['candidate'];

                        $("#startModal").modal('hide');
                        $("#viewVoteCode").val('');

                        $("#votedCandName").html(candidate['name']);
                        $("#votedCandCategory").html(candidate['category']);

                        $("#votedCandImg").attr('src', '../uploads/' + candidate['image']);

                        $("#viewVoteModal").modal('show');

                    } else if (data['success'] == 0) {
                        swal({
                            title: "Invalid code!",
                            // text: "Enter proper verification code!",
                            icon: "error",
                            button: "OK!",
                        });
                    } else {
                        swal({
                            title: "Error!",
                            text: "There is some error!",
                            icon: "error",
                            button: "OK!",
                        });
                    }
                }
            });
        }


    });
</script>